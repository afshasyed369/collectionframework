import java.util.*;
class ListIteratorDemo{
	public static void main(String[] args) {
		LinkedList l=new LinkedList();
		l.add("krish");
		l.add("radha");
		l.add("saadh");
		l.add("ali");
		System.out.println(l);//[krish, radha, saadh, ali]
		ListIterator itr=l.listiterator();
		while(itr.hasNext())
		{
			String s=(String)itr.next();
			if(s.equals("radha"))
			{
				itr.remove();
			}
		}
		System.out.println(l);//[krish, saadh, ali]
	}
}
