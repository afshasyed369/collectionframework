import java.util.*;
class weakhashmap{
	public static void main(String[] args) {
		weakhashmap m=new weakhashmap();
		Temp t=new Temp();
		m.put(t,"sri");
		System.out.println(m);
		t=null;
		System.gc();
		Thread.sleep(5000);
		System.out.println(m);
	}
}
class Temp{
	public String toString() {
		return "Temp";
	}
	public void finalize() {
		System.out.println("finalize() method called");
	}
}