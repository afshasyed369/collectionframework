import java.util.*;
class treemap{
	public static void main(string[] args) {
		treemap t=new treemap();
		t.put(100,"ZZZ");
		t.put(103,"YYY");
		t.put(101,"XXX");
		t.put(104,106);
		t.put(107,null);
		//t.put("FFF","XXX");//ClassCaseException
		//t.put(null,"xxx");//NullPointerException
		System.out.println(t);//{100=ZZZ, 101=XXX, 103=YYY, 104=106, 107null}
	}
}