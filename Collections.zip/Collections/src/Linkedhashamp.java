import java.util.*;
class HashMap{
	public static void main(String[] args) {
		HashMap m=new HashMap();
		Integer i1=new Integer(10);
		Integer i2=new integer(10);
		m.put(i1,"radha");
		m.put(i2,"krishna");
		System.out.println(m);
	}
}
