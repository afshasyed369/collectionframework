import java.util.*;
public class TestJavaCollection3{
	public static void main(String[] args) {
		Vector<String>v=new Vector<String>();
		v.add("Arman");
		v.add("Aashiq");
		v.add("Ruksar");
		v.add("Nadeem");
		Iterator<String>itr = v.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
