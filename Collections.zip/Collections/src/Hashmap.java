import java.util.*;
class HashMap{
	public static void main(String[] args) {
		HashMap m=new HashMap();
		m.put("priya", 700);
		m.put("balu", 800);
		m.put("veeru", 200);
		m.put("annu", 500);
		System.out.println(m); //{annu=500,veeru=200,balu=800,priya=700}
		System.out.println(m.put("priya",100));//700
		Set s=m.keySet();
		System.out.println(s);//[annu,veeru,balu,priya]
		Collection c=m.values();
		System.out.println(c);//[500, 200, 800, 700]
		Set s1=m.entrySet();
		System.out.println(s1);
		Iterator itr=s1.iterator();
		while(itr.hasNext());
		{
			Map.Entry m1=(Map.Entry)itr.next();
			System.out.println(m1.getKey()+"......"+m1.getValue());
			if(m1.getKey().equals("annu"))
			{
				m1.setValue(1000);
			}
		}
		System.out.println(m);
	}
}
